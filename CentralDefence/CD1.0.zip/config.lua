application =
{
	content =
	{
		width = 480,
		height = 320,
		scale = "letterBox"
		--antialias = true
	},
}
